import { randomBytes } from 'crypto'
import { z } from 'zod'
import { supabaseServiceRole, requireSuperAdmin } from '../../../../lib/apiGuards'

const createGlobalUserSchema = z.object({
  email: z.string().trim().email(),
  nom: z.string().trim().min(2),
  role: z.string().trim().min(1),
  client_ids: z.array(z.string().uuid()).optional(),
  telephone: z.string().trim().optional().or(z.literal('')),
  site_web: z.string().trim().url().optional().or(z.literal('')),
  siret_personnel: z.string().trim().optional().or(z.literal('')),
  adresse_pro: z.string().trim().optional().or(z.literal(''))
}).superRefine((data, ctx) => {
  const siret = String(data.siret_personnel || '').replace(/\s+/g, '')
  if (siret && !/^\d{14}$/.test(siret)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Le SIRET personnel doit contenir 14 chiffres.',
      path: ['siret_personnel']
    })
  }
})


function temporaryPassword() {
  return randomBytes(18).toString('base64url')
}

function appOrigin(request) {
  const envUrl = process.env.NEXT_PUBLIC_SITE_URL
  if (envUrl) return envUrl.replace(/\/$/, '')
  const host = request.headers.get('x-forwarded-host') || request.headers.get('host')
  const proto = request.headers.get('x-forwarded-proto') || 'http'
  if (host) return `${proto}://${host}`.replace(/\/$/, '')
  return 'http://localhost:3000'
}

export async function POST(request) {
  try {
    const gate = await requireSuperAdmin(request)
    if (gate.response) return gate.response

    const parsed = createGlobalUserSchema.safeParse(await request.json())
    if (!parsed.success) {
      return Response.json(
        { error: 'Payload invalide.', details: parsed.error.flatten() },
        { status: 400 }
      )
    }
    const {
      email,
      nom,
      role,
      client_ids: clientIds = [],
      telephone = '',
      site_web = '',
      siret_personnel = '',
      adresse_pro = ''
    } = parsed.data

    const password = temporaryPassword()
    const redirectTo = `${appOrigin(request)}/nouveau-mot-de-passe`

    let createResult = await supabaseServiceRole.auth.admin.createUser({
      email,
      password,
      email_confirm: true
    })

    if (createResult.error) {
      const msg = createResult.error.message || ''
      const exists =
        /already\s*(registered|exists)|user\s*already|duplicate/i.test(msg) ||
        createResult.error.status === 422
      if (exists) {
        return Response.json({ error: 'Un compte existe déjà avec cet email.' }, { status: 409 })
      }
    }

    const { data: created, error: errCreate } = createResult
    if (errCreate || !created?.user?.id) {
      return Response.json(
        { error: errCreate?.message || 'Impossible de créer l’utilisateur.' },
        { status: 400 }
      )
    }

    const userId = created.user.id

    // Profil global: client_id NULL, accès gérés par acces_clients.
    const { error: errProfil } = await supabaseServiceRole
      .from('profils')
      .upsert({
        id: userId,
        email,
        nom,
        role,
        client_id: null,
        telephone: telephone || null,
        site_web: site_web || null,
        siret_personnel: (siret_personnel || '').replace(/\s+/g, '') || null,
        adresse_pro: adresse_pro || null
      })

    if (errProfil) {
      await supabaseServiceRole.auth.admin.deleteUser(userId)
      return Response.json({ error: errProfil.message || 'Erreur création profil.' }, { status: 400 })
    }

    if (clientIds.length > 0) {
      const accessRows = clientIds.map((client_id) => ({
        user_id: userId,
        client_id,
        role
      }))

      const { error: errAcces } = await supabaseServiceRole
        .from('acces_clients')
        .insert(accessRows)

      if (errAcces) {
        await supabaseServiceRole.from('profils').delete().eq('id', userId)
        await supabaseServiceRole.auth.admin.deleteUser(userId)
        return Response.json({ error: errAcces.message || 'Erreur création accès.' }, { status: 400 })
      }
    }

    const { error: errRecoveryEmail } = await supabaseServiceRole.auth.resetPasswordForEmail(email, {
      redirectTo
    })
    if (errRecoveryEmail) {
      await supabaseServiceRole.from('acces_clients').delete().eq('user_id', userId)
      await supabaseServiceRole.from('profils').delete().eq('id', userId)
      await supabaseServiceRole.auth.admin.deleteUser(userId)
      return Response.json(
        {
          error:
            errRecoveryEmail.message ||
            'Impossible d’envoyer l’email de réinitialisation (vérifiez SMTP et URL autorisées dans Supabase).'
        },
        { status: 502 }
      )
    }

    return Response.json({
      success: true,
      user_id: userId,
      email
    })
  } catch (err) {
    console.error(err)
    return Response.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

